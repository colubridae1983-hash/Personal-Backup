static void setnetwmicon(void);
